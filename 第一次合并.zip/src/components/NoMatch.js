import React from 'react'

const Com = () => (
  <div className="container">
    <div className="box">404</div>
  </div>
)

export default Com
