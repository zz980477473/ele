import React, { Component } from 'react';
import Footer from '@/components/Footer';

class Com extends Component {
  render () {
    return (
      <div className = "box">
        <header className = "header"></header>
        <div className="content">分类</div>
        <Footer />
      </div>
    )
  }
}

export default Com
