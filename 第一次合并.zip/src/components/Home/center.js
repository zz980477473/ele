const Com = ({prolist}) => {
}

export default Com
